# Github_Tutorial
A very basic and flawed piece of code to show how Github GUI works.
The accompanied tutorial can be found here:
https://learn.sparkfun.com/tutorials/using-github

More information at
https://guides.github.com/activities/hello-world/
